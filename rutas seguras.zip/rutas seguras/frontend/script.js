let map;
let directionsService;
let directionsRenderer;
let geocoder;

function initMap() {
    map = new google.maps.Map(document.getElementById('map'), {
        center: { lat: -12.0500, lng: -77.0282 },
        zoom: 12
    });

    directionsService = new google.maps.DirectionsService();
    directionsRenderer = new google.maps.DirectionsRenderer({ map: map });
    geocoder = new google.maps.Geocoder();

    const origenInput = document.getElementById('origen');
    const destinoInput = document.getElementById('destino');
    new google.maps.places.Autocomplete(origenInput);
    new google.maps.places.Autocomplete(destinoInput);
}

async function calcularRutaSegura() {
    const origen = document.getElementById('origen').value;
    const destino = document.getElementById('destino').value;

    try {
        const origenCoords = await geocodeAddress(origen);
        const destinoCoords = await geocodeAddress(destino);

        const response = await fetch('/api/ruta-segura', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                origen: { lat: origenCoords.lat(), lng: origenCoords.lng() },
                destino: { lat: destinoCoords.lat(), lng: destinoCoords.lng() }
            })
        });

        if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);

        const rutaSegura = await response.json();
        directionsRenderer.setDirections(rutaSegura.directionsResult);

        document.getElementById('informacion-ruta').innerText =
            "Ruta considerada más segura basada en datos de seguridad.";
    } catch (error) {
        console.error("Error al calcular la ruta:", error);
        alert("Ocurrió un error al calcular la ruta.");
    }
}

function geocodeAddress(address) {
    return new Promise((resolve, reject) => {
        geocoder.geocode({ address: address }, (results, status) => {
            if (status === 'OK') {
                resolve(results[0].geometry.location);
            } else {
                reject('Error al geocodificar: ' + status);
            }
        });
    });
}
